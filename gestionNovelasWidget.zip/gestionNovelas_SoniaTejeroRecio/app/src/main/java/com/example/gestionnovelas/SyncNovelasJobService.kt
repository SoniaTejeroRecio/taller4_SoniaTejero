package com.example.gestionnovelas

import android.app.job.JobParameters
import android.app.job.JobService
import android.util.Log

class SyncNovelasJobService : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        Log.d("SyncNovelasJobService", "Job started")
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        Log.d("SyncNovelasJobService", "Job stopped")
        return false
    }
}