package com.example.gestionnovelas

import android.app.Activity
import android.os.Bundle

class NovelaAppWidgetConfigurationActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.novela_appwidget_preview)
    }
}